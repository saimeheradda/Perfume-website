// script.js
document.addEventListener("DOMContentLoaded", () => {
    const loader = document.getElementById("loader");
    const content = document.querySelector(".content");

    // Hide the loader after the content has loaded
    loader.style.display = "none"; // Hide the loader
    content.style.display = "block"; // Show the main content
});

// Perfume Data Array
const perfumes = [
    {
        id: 1,
        name: "Mystic Bliss",
        description: "A blend of floral and woody notes",
        price: "₹2999",
        img: "perfume1.jpeg"
    },
    {
        id: 2,
        name: "Oceanic Dream",
        description: "Fresh and invigorating scent",
        price: "₹2499",
        img: "perfume2.jpeg"
    },
    {
        id: 3,
        name: "Amber Nights",
        description: "Warm and spicy fragrance",
        price: "₹3999",
        img: "perfume3.jpeg"
    },
    {
        id: 4,
        name: "Euphoria",
        description: "Sweet floral bouquet",
        price: "₹1999",
        img: "perfume4.jpg"
    },
    {
        id: 5,
        name: "Sapphire Mist",
        description: "A refreshing and airy scent",
        price: "₹2799",
        img: "perfume5.jpeg"
    },
    {
        id: 6,
        name: "Golden Blossom",
        description: "A luxurious blend of citrus and spice",
        price: "₹3499",
        img: "perfume6.jpeg"
    },
    {
        id: 7,
        name: "Velvet Rose",
        description: "Elegant and refined rose fragrance",
        price: "₹2299",
        img: "perfume7.jpg"
    },
    {
        id: 8,
        name: "Orchid Whisper",
        description: "Mysterious and exotic notes",
        price: "₹3199",
        img: "perfume8.jpg"
    },
    {
        id: 9,
        name: "Lavender Breeze",
        description: "Calming lavender essence",
        price: "₹1899",
        img: "perfume9.jpg"
    },
    {
        id: 10,
        name: "Citrus Zest",
        description: "Bright and energizing citrus notes",
        price: "₹1699",
        img: "perfume10.jpg"
    },
];

// Function to render perfume cards
const renderPerfumes = () => {
    const productsGrid = document.querySelector(".products-grid");
    perfumes.forEach(perfume => {
        const productCard = document.createElement("div");
        productCard.classList.add("product-card");
        productCard.innerHTML = `
            <a href="product.html?id=${perfume.id}">
                <img src="${perfume.img}" alt="${perfume.name}">
                <h3>${perfume.name}</h3>
                <p>${perfume.description}</p>
                <p class="price">${perfume.price}</p>
            </a>
        `;
        productsGrid.appendChild(productCard);
    });
};

document.addEventListener("DOMContentLoaded", renderPerfumes);

// JavaScript for automatic and manual sliding

let slideIndex = 0; // Current slide index

// Function to show a specific slide
function showSlide(index) {
    const slides = document.querySelectorAll('.banner-slide');
    slides.forEach(slide => slide.classList.remove('active'));
    slides[index].classList.add('active');
}

// Function to change slide manually and reset timer
function changeSlide(step) {
    const slides = document.querySelectorAll('.banner-slide');
    slideIndex = (slideIndex + step + slides.length) % slides.length;
    showSlide(slideIndex);
    resetAutoSlide(); // Reset auto-slide when user changes manually
}

// Function to auto-slide
function autoSlide() {
    const slides = document.querySelectorAll('.banner-slide');
    slideIndex = (slideIndex + 1) % slides.length;
    showSlide(slideIndex);
}

// Set interval for automatic slide change
let autoSlideInterval = setInterval(autoSlide, 4000); // Slide every 4 seconds

// Reset auto-slide timer when user navigates manually
function resetAutoSlide() {
    clearInterval(autoSlideInterval);
    autoSlideInterval = setInterval(autoSlide, 4000); // Reset interval
}

// Start by showing the first slide
showSlide(slideIndex);
// Fetch all products
fetch("/api/products")
  .then(response => response.json())
  .then(data => console.log(data))
  .catch(error => console.error("Error fetching products:", error));
  async function fetchProducts() {
    try {
        const response = await fetch('/api/products');
        if (!response.ok) throw new Error('Failed to fetch products');
        
        const products = await response.json();
        const productContainer = document.getElementById('product-container');
        
        // Clear previous products
        productContainer.innerHTML = '';
        
        // Populate products
        products.forEach(product => {
            const productDiv = document.createElement('div');
            productDiv.innerHTML = `
                <h2>${product.name}</h2>
                <p>Price: $${product.price}</p>
                <p>Description: ${product.description}</p>
                <button onclick="fetchReviews('${product._id}')">Show Reviews</button>
                <div id="reviews-${product._id}"></div>
            `;
            productContainer.appendChild(productDiv);
        });
    } catch (error) {
        console.error(error);
    }
}

// Function to fetch reviews for a specific product
async function fetchReviews(productId) {
    try {
        const response = await fetch(`/api/products/${productId}`);
        if (!response.ok) throw new Error('Failed to fetch reviews');
        
        const { product, reviews } = await response.json();
        const reviewContainer = document.getElementById(`reviews-${productId}`);
        
        reviewContainer.innerHTML = reviews.map(review => `
            <p><strong>${review.user}</strong>: ${review.comment} (Rating: ${review.rating})</p>
        `).join('');
    } catch (error) {
        console.error(error);
    }
}

// Call fetchProducts on page load
document.addEventListener('DOMContentLoaded', fetchProducts);


