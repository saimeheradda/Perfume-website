// Perfume data (same array as in script.js for consistency)
const perfumes = [
    {
        id: 1,
        name: "Mystic Bliss",
        description: "Embark on a sensory journey to the ethereal beauty of the Aurora Australis with Mystic Bliss. This captivating unisex fragrance blends aromatic, woody, and fruity notes to evoke the cool Antarctic air and dancing lights of the Southern Hemisphere.",
        price: "₹2999",
        img: "perfume1.jpeg"
    },
    {
        id: 2,
        name: "Oceanic Dream",
        description: "Dive into a serene escape with Ocean Dream, a captivating fragrance that evokes the tranquility of the ocean. This refreshing scent blends marine notes with floral accents, creating a harmonious blend that's both invigorating and soothing.",
        price: "₹2499",
        img: "perfume2.jpeg"
    },
    {
        id: 3,
        name: "Amber Nights",
        description: "Indulge in the captivating allure of Amber Nights, a fragrance that evokes the warmth and mystique of twilight. This opulent perfume is a harmonious blend of rich amber, exotic spices, and velvety woods, creating a truly unforgettable scent experience.",
        price: "₹3999",
        img: "perfume3.jpeg"
    },
    {
        id: 4,
        name: "Euphoria",
        description: "Indulge in the captivating allure of Euphoria, a fragrance that embodies the essence of feminine power and mystery.his intoxicating scent is a harmonious blend of fruity, floral, and woody notes that awaken the senses and ignite the imagination. ",
        price: "₹1999",
        img: "perfume4.jpg"
    },
    {
        id: 5,
        name: "Sapphire Mist",
        description: "Indulge in the ethereal beauty of Sapphire Mist, a fragrance that captures the essence of a serene summer day. This delicate and refreshing scent is a harmonious blend of floral and aquatic notes, designed to uplift your senses and leave a lasting impression.",
        price: "₹2799",
        img: "perfume5.jpeg"
    },
    {
        id: 6,
        name: "Golden Blossom",
        description: "Embrace the elegance of Golden Blossom, a captivating fragrance that blooms with floral radiance. This enchanting perfume opens with a delicate bouquet of jasmine, inviting you into a world of pure floral delight. As the fragrance unfolds, a heart of soft, velvety rose takes center stage, adding a touch of romance and sophistication. The base notes of warm amber and sandalwood create a lingering trail of sensuality, leaving a lasting impression.",
        price: "₹3499",
        img: "perfume6.jpeg"
    },
    {
        id: 7,
        name: "Velvet Rose",
        description: "Indulge your senses with Velvet Rose, a captivating fragrance that blooms with the elegance of a thousand roses. This enchanting perfume opens with a delicate bouquet of fresh, velvety rose petals, intertwined with earthy patchouli for a touch of intrigue. As the fragrance unfolds, a warm and comforting heart of creamy musk and sensual labdanum emerges, enveloping you in a cloud of pure luxury. The dry down reveals a rich and alluring base of amber, adding depth and sophistication to this timeless scent.",
        price: "₹2299",
        img: "perfume7.jpg"
    },
    {
        id: 8,
        name: "Orchid Whisper",
        description: "Orchid Whisper is a captivating fragrance that evokes the serene beauty of a blooming orchid garden. This exquisite perfume opens with a refreshing blend of tea, bergamot, and osmanthus, awakening your senses with a burst of citrusy and floral notes.",
        price: "₹3199",
        img: "perfume8.jpg"
    },
    {
        id: 9,
        name: "Lavender Breeze",
        description: "Lavender Breeze: Your Daily Dose of Calm Elevate your mood and reduce stress with Lavender Breeze. This soothing fragrance is infused with pure lavender essential oil, known for its calming properties. Spritz it on to promote relaxation and unwind after a long day.",
        price: "₹1899",
        img: "perfume9.jpg"
    },
    {
        id: 10,
        name: "Citrus Zest",
        description: "Experience the invigorating freshness of Citrus Zest, a fragrance that captures the essence of summer in every spritz. This vibrant and uplifting scent is a harmonious blend of zesty citrus notes, creating a truly refreshing and energizing olfactory experience.",
        price: "₹1699",
        img: "perfume10.jpg"
    },
];

// Display product details
const renderProductDetails = () => {
    const params = new URLSearchParams(window.location.search);
    const productId = parseInt(params.get("id"));
    const product = perfumes.find(p => p.id === productId);

    if (product) {
        const productContainer = document.querySelector(".product-details-container");
        productContainer.innerHTML = `
            <div class="product-details">
                <img src="${product.img}" alt="${product.name}" class="product-img">
                <div class="product-info">
                    <h2>${product.name}</h2>
                    <p class="product-description">${product.description}</p>
                    <p class="product-price">${product.price}</p>
                    <button class="share-now">Share Now</button>
                </div>
            </div>
        `;

        // Add share functionality
        const shareButton = document.querySelector(".share-now");
        shareButton.addEventListener("click", () => {
            if (navigator.share) { // Check if Web Share API is supported
                navigator.share({
                    title: product.name,
                    text: product.description,
                    url: window.location.href
                })
                .then(() => console.log('Shared successfully!'))
                .catch((error) => console.error('Error sharing:', error));
            } else {
                alert("Sharing is not supported on this browser.");
            }
        });
    } else {
        document.querySelector(".product-details-container").innerHTML = "<p>Product not found.</p>";
    }
};

document.addEventListener("DOMContentLoaded", renderProductDetails);

document.addEventListener("DOMContentLoaded", function() {
    const reviewForm = document.getElementById("reviewForm");
    const reviewsContainer = document.getElementById("reviewsContainer");
    const totalRatingElement = document.createElement("p");
    totalRatingElement.className = "total-rating";
    reviewsContainer.before(totalRatingElement);
  
    // Array to store each rating value
    const ratings = [];
  
    // Update total rating
    const updateTotalRating = () => {
      if (ratings.length > 0) {
        const sum = ratings.reduce((acc, rating) => acc + rating, 0);
        const averageRating = (sum / ratings.length).toFixed(1);
        totalRatingElement.textContent = `Average Rating: ${averageRating} ★ (${ratings.length} reviews)`;
      } else {
        totalRatingElement.textContent = "No reviews yet.";
      }
    };
  
    // Handle form submission
    reviewForm.addEventListener("submit", function(event) {
      event.preventDefault();
  
      // Get input values
      const name = document.getElementById("name").value;
      const rating = parseInt(document.getElementById("rating").value);
      const comment = document.getElementById("comment").value;
  
      // Add rating to the array
      ratings.push(rating);
  
      // Create a new review element
      const reviewElement = document.createElement("div");
      reviewElement.classList.add("review");
  
      reviewElement.innerHTML = `
        <p class="reviewer-name">${name}</p>
        <p class="review-rating">Rating: ${"★".repeat(rating)}</p>
        <p class="review-comment">${comment}</p>
      `;
  
      // Add the new review to the reviews container
      reviewsContainer.appendChild(reviewElement);
  
      // Update the total rating display
      updateTotalRating();
  
      // Reset the form
      reviewForm.reset();
    });
  
    // Initial display for total rating
    updateTotalRating();
  });
  


document.addEventListener("DOMContentLoaded", () => {
    // Example product data
    const product = {
        title: "Floral Essence",
        description: "A delightful blend of floral notes that captivates the senses.",
        images: [
            "image1.jpg",
            "image2.jpg",
            "image3.jpg",
        ],
        reviews: [
            { user: "Alice", comment: "Absolutely love this fragrance!" },
            { user: "Bob", comment: "Not what I expected, but nice." }
        ]
    };

    // Get the elements
    const titleElement = document.querySelector(".product-title");
    const descriptionElement = document.querySelector(".product-description");
    const galleryElement = document.querySelector(".product-image-gallery");
    const reviewsElement = document.querySelector(".product-reviews");

    // Set the title
    titleElement.textContent = product.title;

    // Set the description
    descriptionElement.textContent = product.description;

    // Render the image gallery
    product.images.forEach(image => {
        const img = document.createElement("img");
        img.src = image;
        img.alt = product.title;
        galleryElement.appendChild(img);
    });

    // Render the reviews
    if (product.reviews.length > 0) {
        const reviewsHeader = document.createElement("h3");
        reviewsHeader.textContent = "Customer Reviews";
        reviewsElement.appendChild(reviewsHeader);

        product.reviews.forEach(review => {
            const reviewDiv = document.createElement("div");
            reviewDiv.className = "review";
            reviewDiv.innerHTML = `<strong>${review.user}</strong>: ${review.comment}`;
            reviewsElement.appendChild(reviewDiv);
        });
    }
// Add this to product.js for handling reviews
document.addEventListener("DOMContentLoaded", function() {
  const reviewForm = document.getElementById("reviewForm");
  const reviewsContainer = document.getElementById("reviewsContainer");

  // Handle form submission
  reviewForm.addEventListener("submit", function(event) {
    event.preventDefault();

    // Get input values
    const name = document.getElementById("name").value;
    const rating = document.getElementById("rating").value;
    const comment = document.getElementById("comment").value;

    // Create a new review element
    const reviewElement = document.createElement("div");
    reviewElement.classList.add("review");

    reviewElement.innerHTML = `
      <p class="reviewer-name">${name}</p>
      <p class="review-rating">Rating: ${"★".repeat(rating)}</p>
      <p class="review-comment">${comment}</p>
    `;

    // Add the new review to the reviews container
    reviewsContainer.appendChild(reviewElement);

    // Reset the form
    reviewForm.reset();
  });
});

   /* // Share button functionality
    const shareButtons = document.querySelector(".share-buttons");
    const platforms = ["Facebook", "Twitter", "Pinterest"];
    platforms.forEach(platform => {
        const button = document.createElement("button");
        button.textContent = `Share on ${platform}`;
        button.onclick = () => alert(`Shared on ${platform}`);
        shareButtons.appendChild(button); 
    }); */
});
