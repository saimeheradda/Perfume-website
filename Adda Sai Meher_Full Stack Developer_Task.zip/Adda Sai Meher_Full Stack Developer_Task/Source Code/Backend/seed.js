const mongoose = require("mongoose");
const Product = require("./models/product1");
const Review = require("./models/Review");

mongoose.connect("mongodb://localhost:27017/myDatabase", { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log("Connected to MongoDB for seeding"))
  .catch((err) => console.log("DB Connection Error:", err));

const seedDatabase = async () => {
  await Product.deleteMany({});
  await Review.deleteMany({});

  const products = [
    { name: "Product 1", price: 100, description: "Description 1", category: "Category 1", stock: 10 },
    { name: "Product 2", price: 200, description: "Description 2", category: "Category 2", stock: 20 },
  ];

  const reviews = [
    { productId: products[0]._id, user: "User 1", rating: 5, comment: "Great product!" },
    { productId: products[1]._id, user: "User 2", rating: 4, comment: "Very good product!" },
  ];

  await Product.insertMany(products);
  await Review.insertMany(reviews);

  console.log("Database seeded");
  mongoose.connection.close();
};

seedDatabase();
